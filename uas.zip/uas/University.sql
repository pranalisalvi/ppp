--drop tables
DROP TABLE Location CASCADE CONSTRAINTS;
DROP TABLE Programs_Scheduled CASCADE CONSTRAINTS;
DROP TABLE Application CASCADE CONSTRAINTS;
DROP TABLE Programs_Offered CASCADE CONSTRAINTS;
DROP TABLE Participant CASCADE CONSTRAINTS;
DROP TABLE Users CASCADE CONSTRAINTS;

--drop sequences
DROP SEQUENCE location_id;
DROP SEQUENCE scheduled_program_id;
DROP SEQUENCE roll_no;
DROP SEQUENCE application_id;


--Create tables
CREATE TABLE Location(
 LocationID varchar2(10) primary key,
 city varchar2(10),
 hstate varchar2(20),
 zip varchar2(10)
 );
 
CREATE TABLE Programs_Scheduled (
 Scheduled_program_id varchar2(5) primary key,
 ProgramName varchar2(15),
 LocationID varchar2(10)  REFERENCES Location(LocationID) ,
 start_date date,
 end_date date,
 sessions_per_week number
 );
 
CREATE TABLE Application(
Application_id number(25) primary key,
full_name varchar2(20),
date_of_birth date,
highest_qualification varchar2(10),
marks_obtained number, 
goals varchar2(20),
 email_id varchar2(20),
 Scheduled_program_id varchar2(5) REFERENCES Programs_Scheduled(Scheduled_program_id),
 status varchar2(10),
Date_Of_Interview date
);

CREATE TABLE Programs_Offered(
 ProgramName varchar2(15) , 
 description varchar2(100),
 applicant_eligibility varchar2(50) ,
 duration number,
 degree_certificate_offered varchar2(10)
 );
 
CREATE TABLE Participant (
 Roll_no varchar2(5) primary key,
 email_id varchar2(20),
 Application_id  number(25) REFERENCES Application(Application_id) ,
 Scheduled_program_id varchar2(5) REFERENCES Programs_Scheduled(scheduled_program_id)
 );
 
CREATE TABLE Users (
 login_id varchar2(5) primary key,
 password varchar2(10),
 role varchar2(5)
) ;

--create sequences
CREATE SEQUENCE location_id start with 107 increment by 1;
CREATE SEQUENCE scheduled_program_id start with 505 increment by 1;
CREATE SEQUENCE roll_no start with 3 increment by 1;
CREATE SEQUENCE application_id start with 1008 increment by 1;


--alter constraints

ALTER TABLE Application ADD CONSTRAINT user_applications CHECK (status in ('applied','accepted','rejected','confirmed'));
ALTER TABLE Application modify status DEFAULT 'applied';
ALTER TABLE Users ADD CONSTRAINT user_check CHECK (role in ('admin','mac'));


--Insert statements

--LOCATION
Insert into Location values(101,'Mumbai','Maharashtra',400092);
Insert into Location values(102,'Pune','Maharashtra',400123);
Insert into Location values(103,'Patna','MP',400628);
Insert into Location values(104,'Kanpur','UP',400593);
Insert into Location values(105,'Kolkata','WestBengal',400236);
Insert into Location values(106,'Nagpur','Maharashtra',400638);

--PROGRAMS_SCHEDULED
INSERT INTO Programs_Scheduled values(501,'Core Java',103,'13-JUN-2017','13-SEP-2017',6);
INSERT INTO Programs_Scheduled values(502,'.NET',101,'13-JUN-2017','13-SEP-2017',5);
INSERT INTO Programs_Scheduled values(503,'SocialAnalytics',104,'13-JUN-2017','13-SEP-2017',5);
INSERT INTO Programs_Scheduled values(504,'Database',105,'13-JUN-2017','13-SEP-2017',4);

--APPLICATION
Insert into Application values(1001,'Nikhil Pandey','21-NOV-1994','BE',99,'Java Developer','nikhil@gmail.com',501,'accepted','20-MAR-2017');                          
Insert into Application values(1002,'Pranali Sawant','01-SEP-1993','BE',75,'Manager','pranalis@gmail.com',503,'confirmed','21-APR-2017');
Insert into Application values(1003,'Nehali Pansare','13-FEB-1995','BE',79,'Team Leader','pansaren@ymail.com',502,'accepted','22-MAR-2017');
Insert into Application values(1004,'Pooja Pal','30-JULY-1994','BE',83,'Tester','palpooja@yahoo.com',501,'applied','12-MAY-2017');
Insert into Application values(1005,'Rhitika Shetty','25-DEC-1995','BE',69,'Group Leader','rhitika@gmail.com',503,'confirmed','21-APR-2017');
Insert into Application values(1006,'Amruta Patil','11-MAR-1993','BE',86,'App Developer','amrutap@gmail.com',502,'applied','12-MAY-2017');
Insert into Application values(1007,'Jaini Parikh','13-OCT-1994','BE',59,'Java Devloper','jainip@gmail.com',501,'rejected','12-MAY-2017');

--PROGRAMS_OFFERED
Insert into Programs_Offered values('Core Java','Basics of java','IT students/ professionals/ engineers',8,'OCPJP');
Insert into Programs_Offered values('.NET',' The course will train you to build solutions for pc servers, mobile phones and embedded devices.','IT students/ professionals/ engineers',7,'MCTS'); 
Insert into Programs_Offered values('SocialAnalytics',' Social and analytics helps organisations to improve customer satisfaction.','Graduates/ post-graduates/ MBA',9,'UCI');
Insert into Programs_Offered values('Database','Learn concepts and application of database handling with SQL Server 2008.','Engineers/Students/Graduates/Anyone',7,'MCITP');
 
--PARTICIPANT
Insert into  Participant values(1,'nikhil@gmail.com',1001,501);
Insert into  Participant values(2,'pansaren@ymail.com',1003,502);

--USERS
Insert into  Users values('A202','jaini','admin');
Insert into  Users values('A203','nikhil','mac');
Insert into  Users values('A204','pranali','mac');
 
commit;

