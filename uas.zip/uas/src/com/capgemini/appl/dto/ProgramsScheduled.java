package com.capgemini.appl.dto;

import java.util.List; 

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity(name="programScheduled")
@Table(name="PROGRAMS_SCHEDULED ")
@NamedQueries({
   
	 @NamedQuery(name="qryScheduled", query="select p from programScheduled p where   startDate>=:sdate  AND endDate<=:ndate")
	})

@SequenceGenerator(name="prgmscheduled_generate",sequenceName="SCHEDULED_PROGRAM_ID",allocationSize=1,initialValue=501)
public class ProgramsScheduled {
	
	int scheduledProgramId;
	//String ProgramName;
//	String locationID;
	java.sql.Date startDate;
	java.sql.Date endDate;
	int sessionsPerWeek;
    private Location location;
	ProgramsOffered program;
	List<Application> application;
	
	
	@OneToMany(mappedBy = "scheduled")
	public List<Application> getApplication() {
		return application;
	}

	public void setApplication(List<Application> application) {
		this.application = application;
	}

	@Id
	@Column(name="SCHEDULED_PROGRAM_ID")
	@GeneratedValue(generator="prgmscheduled_generate",strategy=GenerationType.SEQUENCE)
	public int getScheduledProgramId() {
		return scheduledProgramId;
	}



	public void setScheduledProgramId(int scheduledProgramId) {
		this.scheduledProgramId = scheduledProgramId;
	}

	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="ProgramName")
	public ProgramsOffered getProgram() {
		return program;
	}

	public void setProgram(ProgramsOffered program) {
		this.program = program;
	}

	
	/*
	@NotEmpty(message="Name is required")
	@Column(name="PROGRAMNAME")
	public String getProgramName() {
		return ProgramName;
	}

	public void setProgramName(String programName) {
		ProgramName = programName;
	}
*/
	/*@Column(name="LOCATIONID")
	public String getLocationID() {
		return locationID;
	}

	public void setLocationID(String locationID) {
		this.locationID = locationID;
	}*/
	//@NotNull(message="Start Date is required")
	@Column(name="START_DATE")
	public java.sql.Date getStartDate() {
		return startDate;
	}

	public void setStartDate(java.sql.Date startDate) {
		this.startDate = startDate;
	}
	//@NotNull(message="End Date is required")
	@Column(name="END_DATE")
	public java.sql.Date getEndDate() {
		return endDate;
	}

	public void setEndDate(java.sql.Date endDate) {
		this.endDate = endDate;
	}

	//@NotEmpty(message="session per week is required")
	@Column(name="SESSIONS_PER_WEEK")
	public int getSessionsPerWeek() {
		return sessionsPerWeek;
	}

	public void setSessionsPerWeek(int sessionsPerWeek) {
		this.sessionsPerWeek = sessionsPerWeek;
	}
	
	
/*	@OneToOne()
	@JoinColumn(name="LOCATIONID")
	public Location getLocation(){
		return location;
	}*/
	
/*	  public void setLocation(Location location) {
	        this.location = location;
	    }*/
	

	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="locationid")
	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	@Override
	public String toString() {
		return "ProgramsScheduled [scheduledProgramId=" + scheduledProgramId
				+ ", startDate=" + startDate + ", endDate=" + endDate
				+ ", sessionsPerWeek=" + sessionsPerWeek + ", location="
				+ location + ", program=" + program + "]";
	}

	


	
}
