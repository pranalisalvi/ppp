/*********************************************************************
 * File                 : EmpCrudController.java

 * Author Name          : NIKHIL PANDEY
 * Desc                 : JAVA Controller
 * Version              : 1.0
 * Creation Date        : 31-Mar-2017
 * Last Modified Date   : 31-Mar-2017
 *********************************************************************/
package com.capgemini.appl.controlers;


import java.text.SimpleDateFormat;
import java.util.ArrayList;


import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.appl.dto.Application;
import com.capgemini.appl.dto.ProgramsScheduled;
import com.capgemini.appl.exception.UniversityAdmissionException;
import com.capgemini.appl.service.UniversityService;

import sun.util.logging.resources.logging;


@Controller
public class UniversityCrudController {
	private UniversityService service;
	List<String> designation;

	
	@Resource(name = "universityService")
	public void setEmpServices(UniversityService service) {
		this.service = service;
	}

	//Default Page of Project
	@RequestMapping("index")
	public ModelAndView welcome() {
		ModelAndView model=new ModelAndView("index");
		return model;

	}		
	////////////////////////////////////////////////////////
	@RequestMapping("applicant")
	public ModelAndView applicant() {
		ModelAndView model=new ModelAndView("applicant");
		return model;
	}

	
	@RequestMapping("showApplicant")
	public ModelAndView showApplicant() {
		ModelAndView modelAndView=null;		try {
			List<Application> list=service.showApplications();
			System.out.println(service.showApplications());
			modelAndView=new ModelAndView("error");
			modelAndView.addObject("msg", list);
		} catch (UniversityAdmissionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return modelAndView;
	}
	
	
	@RequestMapping("showAddProgram")
	public ModelAndView showaddProgram() {
		ModelAndView modelAndView=new ModelAndView("addProgram");	
		return modelAndView;
	}
	/////////////////////////////////////////////////
/*	//show List of Employee
	@RequestMapping("showAllEmps")
	public ModelAndView showAllEmps() {
		ModelAndView model = null;
		try {
			List<Emp> list = service.getAllEmps();
			model = new ModelAndView("showAllEmps");
			model.addObject("list", list);
		} catch (EmpEcxeption e) {
			model = new ModelAndView("error");
			model.addObject("msg", e);
		}
		return model;
	}

	//Navigate to New Employee Entry Form
	@RequestMapping("addNewEmp")
	public ModelAndView addNew(ModelAndView model) {

		Emp emp = new Emp();
		model.addObject("emp", emp);
		model.addObject("designation", designation);
		model.setViewName("addNewEmp");
		return model;

	}

	//Add Employee to Database Or Show error
	@RequestMapping("addEmp")
	public ModelAndView addEmp(@ModelAttribute @Valid Emp emp,
			BindingResult result) {
		ModelAndView model = new ModelAndView();
		if (result.hasErrors()) {
			model.addObject("emp", emp);
			model.addObject("designation", designation);
			model.setViewName("addNewEmp");
			return model;
		}

		try {
			Emp myemp = service.insertNewEmp(emp);
			model.addObject("emp", myemp);
			model.setViewName("successEmp");
			return model;
		} catch (EmpEcxeption e) {
			model.setViewName("error");
			model.addObject("msg", e);
			return model;
		}

	}
*/
	
	
	@RequestMapping("showProgramReport")
	public ModelAndView showProgramReport(ModelAndView model) {

		
		model.setViewName("programReport");
		model.addObject("scheduled", new ProgramsScheduled());
		return model;

	}

	@RequestMapping("programReport")
		public ModelAndView submitEntryForm(@ModelAttribute  ProgramsScheduled scheduled, BindingResult result){
			
			ModelAndView model= new ModelAndView();
			
			if(result.hasErrors()){
				System.out.println(result.getAllErrors());
				model.setViewName("programReport");

				model.addObject("scheduled", scheduled);  //enter value of trainee that store in trainee object,so create before jsp
				
				
				return model;
			}
			try {
				
				
				List<ProgramsScheduled> scheduledResponse=service.showProgramInfo(scheduled);
				
				model.setViewName("programInfo");
				model.addObject("programinfo", scheduledResponse);
			} catch (UniversityAdmissionException e) {
				model = new ModelAndView("error");
				model.addObject("msg", "Show Failed: "+e.getMessage());
				
			}
			return model;
		}
		
		
	
	@RequestMapping("/loadViewstatus.do")
	public ModelAndView enterApplicantNo(){
		System.out.println("In Controlling method");
		ModelAndView model= new ModelAndView("viewStatus");
		
		
		return model;
	}
	
			//serch by no.
	@RequestMapping("/viewStatus.do")
	public ModelAndView getTraineeDetails( @RequestParam  ("applicationId") @Valid int applicationId,BindingResult result ){   
		
		System.out.println("In Controlling method"+ applicationId);
		
		ModelAndView model;
		try {
			Application app= service.showStatus(applicationId);
			if(app==null){
				model= new ModelAndView("viewStatus");
				model.addObject("msg", "Applicant not found");
				return model;
			}
			model = new ModelAndView("status");
			model.addObject("status",app);               //object of emp 
		} catch (UniversityAdmissionException e) {
			model= new ModelAndView("error");
			model.addObject("msg", e.getMessage());
		}
		
		return model;
		
	}
	
	
	
}

